/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto1;

/**
 *
 * @author Sebastián Castillo, Martin Urdaneta, Yargen Gonzalez 
 */
public class Proyecto1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MenuPrincipal test = new MenuPrincipal();
        test.setVisible(true);
        
        
    }
  
}
